# Web_Development
LANGUAGES USED HTML, CSS & JAVA.
WE ARE PART OF A COMMUNITY, "ARYANS CYBER SECURITY AWARENESS COMMUNITY". PUROSE OF THIS WEB PAGE IS SPARED AWARENESS RELATED TO CYBER FRAUD/FISHING/SCAMS etc. AMONG THE PEOPLE.



IN THIS WEB PAGE WANTS TO ADD FOLLOWING KEYWORDS:



"Home" page in which add some contents examples: -Title, Slide show pictures, add slogoan, logo etc
"About" in this section wants to add some contents related to our community and aim. 
"Log in & registration" page for who wants to write and share their ideas about cyber security and as well as they can share their personal blogs. 
"Slide Show" some pictures related to cyber security awareness.
"Gallery"
"Achievments section"


key points:
It is free anyone can join and share their ideas & technology with AI systems on Cyber Security Awareness.



Thanking you.....
